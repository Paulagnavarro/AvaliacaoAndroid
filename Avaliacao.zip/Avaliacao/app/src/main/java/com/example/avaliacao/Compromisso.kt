package com.example.avaliacao

data class Compromisso(var titulo: String, var data: String, var horarioInicio: String, var horarioTermino: String,
       var descDetalhada: String)  {
}