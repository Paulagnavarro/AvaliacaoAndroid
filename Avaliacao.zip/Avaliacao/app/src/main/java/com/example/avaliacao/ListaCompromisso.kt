package com.example.avaliacao

class ListaCompromisso private constructor(){

    companion object { // atributos e metodos static no java

        private var listaCompromisso = mutableListOf<Compromisso>()

        init {
            listaCompromisso.add(Compromisso("Estudar", "14/09/2023",
                "5:00","7:00", "Estudar programação"))

            listaCompromisso.add(Compromisso("Trabalhar", "15/09/2023",
                "9:00", "17:00", "Trabalhar em um projeto"))
        }


        fun addCompromisso(compromisso: Compromisso){
            listaCompromisso.add(compromisso)
        }

        fun getCompromisso(position: Int) : Compromisso{
            return listaCompromisso[position]
        }

        fun removeCompromisso(position: Int){
            listaCompromisso.removeAt(position)
        }

        fun getListSize() : Int {
            return listaCompromisso.size
        }

    }
}