package com.example.avaliacao

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.os.bundleOf
import com.example.avaliacao.databinding.ActivityDetalhesBinding

class DetalhesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetalhesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDetalhesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var position = intent.getIntExtra("position", -1)

        if (position == -1) {
            finish()
        }

        var compromisso = ListaCompromisso.getCompromisso(position)

        binding.txtTitulo.text = compromisso.titulo
        binding.txtData.text = compromisso.data
        binding.txtHorarioInicio.text = compromisso.horarioInicio
        binding.txtHorarioTermino.text = compromisso.horarioTermino
        binding.txtDescDetalhada.text = compromisso.descDetalhada

        binding.btnExcluir.setOnClickListener {
            ListaCompromisso.removeCompromisso(position)
            finish()
        }

    }
}