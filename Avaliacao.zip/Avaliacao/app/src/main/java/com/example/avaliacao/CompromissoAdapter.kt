package com.example.avaliacao

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class CompromissoAdapter(var context: Context) : RecyclerView.Adapter<CompromissoViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CompromissoViewHolder {
        var layoutCompromisso = LayoutInflater.from(parent.context)
            .inflate(R.layout.layout_compromisso, parent, false)
        var compromissoViewHolder = CompromissoViewHolder(layoutCompromisso)
        return compromissoViewHolder
    }

    override fun onBindViewHolder(holder: CompromissoViewHolder, position: Int) {
        var compromisso = ListaCompromisso.getCompromisso(position)
        holder.txtTituloData.text = "${compromisso.titulo} (${compromisso.data})"

        holder.txtTituloData.setOnLongClickListener {

            var intent = Intent(context, DetalhesActivity::class.java)
            intent.putExtra("position", position)
            context.startActivity(intent)
            true
        }


    }

    override fun getItemCount(): Int {
        return ListaCompromisso.getListSize()
    }
}