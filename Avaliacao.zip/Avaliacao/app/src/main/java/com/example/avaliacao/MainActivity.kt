package com.example.avaliacao

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.avaliacao.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var compromissoAdapter: CompromissoAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        compromissoAdapter = CompromissoAdapter(this)
        binding.rcvCompromisso.layoutManager = LinearLayoutManager(this)
        binding.rcvCompromisso.adapter = compromissoAdapter

        binding.btnAddCompromisso.setOnClickListener {
            startActivity(Intent(this, CadastroActivity::class.java))
        }


    }

    override fun onStart() {
        super.onStart()
        compromissoAdapter.notifyDataSetChanged()
    }
}